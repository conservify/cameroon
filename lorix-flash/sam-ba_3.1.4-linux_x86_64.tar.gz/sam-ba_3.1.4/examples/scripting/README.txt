# SAM-BA scripting examples

Sample scripts to demonstrate SAM-BA scripting features.

## arguments.qml

This script demonstrates how to retrieve some custom arguments from the
SAM-BA tool command-line.

## return-code.qml

This script demonstrates how to change the SAM-BA tool return code.
